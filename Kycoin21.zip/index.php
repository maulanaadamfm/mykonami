<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">
	<meta name="description" content="Get coins eFootball Pes for fre">
	<meta property="og:url" content="">
	<meta property="og:type" content="website">
	<meta property="og:title" content="Free Coins eFootball pes 2021">
	<meta property="og:description" content="Get coins eFootball Pes 2021 for free.">
	<meta property="og:site_name" content="eFootball.Open">
	<meta property="og:image" content="">
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:site" content="Free Coins eFootball League">
	<meta name="twitter:description" content="Get coins eFootball Pes 2021 for free.">
	<meta name="twitter:image" content="">
    <title>eFootball pes 2021 Event</title>
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <nav class="navbar navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="./">
                <img class="img-navbar" src="img/konami_logo_normal.png">
            </a>

            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">&nbsp;</span></a>
                </li>
            </ul>

            <span class="navbar-text text-white">
                eFootball Pes 2021 Free Coins
            </span>
        </div>
    </nav>
    <div class="container">
        <div class="row text-center">
            <div class="col-md-12 text-center mt-2">
                <div class="sub-header">
                    <img src="img/logo_efootball_open.png" class="img-sub-header" alt="">
                </div>
            </div>
        </div>

        <div class="row mt-2">
            <div class="col-lg-6 col-sm-12 text-center">
                <table colspan="6">
                    <tr>
                        <td><img class="img-inner" src="img/coin/1050.png" alt=""></td>
                        <td align="left">
                            <div class="anu">
                                <span>Free coins eFootball PES 2021</span>
                                <button type="button" onclick="location.href='auth.php';" class="btn-claim">CLAIM</button>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="col-lg-6 col-sm-12 mt-3 text-center">
                <table colspan="6">
                    <tr>
                        <td><img class="img-inner" src="img/coin/2150.png" alt=""></td>
                        <td align="left">
                            <div class="anu">
                                <span>Free coins eFootball PES 2021</span>
                                <button type="button" onclick="location.href='auth.php';" class="btn-claim">CLAIM</button>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="col-lg-6 col-sm-12 mt-3 text-center">
                <table colspan="6">
                    <tr>
                        <td><img class="img-inner" src="img/coin/3300.png" alt=""></td>
                        <td align="left">
                            <div class="anu">
                                <span>Free coins eFootball PES 2021</span>
                                <button type="button" onclick="location.href='auth.php';" class="btn-claim">CLAIM</button>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="col-lg-6 col-sm-12 mt-3 text-center">
                <table colspan="6">
                    <tr>
                        <td><img class="img-inner" src="img/coin/5800.png" alt=""></td>
                        <td align="left">
                            <div class="anu">
                                <span>Free coins eFootball PES 2021</span>
                                <button type="button" onclick="location.href='auth.php';" class="btn-claim">CLAIM</button>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="col-lg-6 col-sm-12 my-3 text-center">
                <table colspan="6">
                    <tr>
                        <td><img class="img-inner" src="img/coin/12000.png" alt=""></td>
                        <td align="left">
                            <div class="anu">
                                <span>Free coins eFootball PES 2021</span>
                                <button type="button" onclick="location.href='auth.php';" class="btn-claim">CLAIM</button>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>