<?php 
$emailku = "contoh@gmail.com"; // Email loe
?>